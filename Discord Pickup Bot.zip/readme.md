## Read me 

# Discord Pickup bot for Quake live

> Work in progress

