{
  "embed": {
    "color": 2229666,
    "fields": [
      {
        "name": "Players",
        "value": "Majin\nvcx\nWallsnag\nVincent\nScorpion\nMakie"
      }
    ]
  }
}